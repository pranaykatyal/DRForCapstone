import numpy as np
import matplotlib.pyplot as plt

from network_agent import NetworkAgent
from distributed_algorithm import run_ctl_sim_circle, dist_ccw, dist_cw, plot_agents
from math import pi, sin, cos

# Network -- S_circle first-order agents in S^1 with absolute sensing of own position, communication range r
# Algorithm -- Agree & Pursue
# Alphabet -- A=S^1x{c,cc}xIU{null}

# Processor State: w=(dir,max-id), where
# dir in {c,cc}; initially, dir[i] unspecified
# max-id in I; initially, max-id[i]=i for all i

class AgreePursueAgent(NetworkAgent):

    def __init__(self):
        pass

    def step(self):
        pass

    def msg(self):
        pass

    def stf(self):
        pass

    def ctl(self):
        pass

    def clear_msgs(self):
        pass

    def add_msg(self):
        pass

# add any helper functions you would like here

if __name__=="__main__":

    # create any parameters you need here (e.g., number of agents, communication radius, etc.)

    # generate positions randomly from 0 to 2 pi and directions randomly between clockwise and counterclockwise

    # initialize array of agents with -1 for direction and i for i-max

    # run_ctl_sim_circle from distributed_algorithm, passing in your agents as input
    # sim needs to simulate continuous dynamics with discrete time messages and updates
    
    pass