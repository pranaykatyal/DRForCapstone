import networkx as nx
from network_agent import NetworkAgent
from distributed_algorithm import run_sim


# Define your agent as a subclass of Network Agent
# Include all of the necessary methods
class ConsensusAgent(NetworkAgent):

    def __init__(self):
        pass

# Define any helper functions you would like to use

# Main loop
if __name__=="__main__":

    # Create a graph with the appropriate number of nodes

    # Initialize the agents with appropriate initial values

    # run_sim from distributed_algorithm, passing in your agents as input

    # Print the results of the consensus algorithm over time

    pass